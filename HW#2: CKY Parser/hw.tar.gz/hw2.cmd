executable     = /home2/vdhaya/ling571/hw2/hw2_parser.sh
arguments      = "grammar_cnf.cfg sentences.txt hw2_output.txt"
initialdir     = /home2/vdhaya/ling571/hw2
getenv         = true
output         = hw2.stdout
error          = hw2.error
log            = hw2.log
notification   = never
request_memory = 512
queue
